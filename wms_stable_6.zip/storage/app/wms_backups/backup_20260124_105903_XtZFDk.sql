-- WMS Backup (fallback)
-- Generated: 2026-01-24 10:59:03

DROP TABLE IF EXISTS `app_settings`;
CREATE TABLE `app_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `app_settings` (`id`,`key`,`value`,`created_at`,`updated_at`) VALUES
('1','default_low_stock_threshold','10','2026-01-24 10:48:14','2026-01-24 10:48:14');

DROP TABLE IF EXISTS `backup_settings`;
CREATE TABLE `backup_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `frequency` enum('daily','weekly') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'daily',
  `weekly_day` tinyint unsigned NOT NULL DEFAULT '1',
  `time_hm` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '02:00',
  `backup_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_run_at` timestamp NULL DEFAULT NULL,
  `last_backup_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `backup_settings` (`id`,`enabled`,`frequency`,`weekly_day`,`time_hm`,`backup_path`,`last_run_at`,`last_backup_file`,`created_at`,`updated_at`) VALUES
('1','0','daily','1','02:00','wms_backups',NULL,NULL,'2026-01-24 07:13:34','2026-01-24 07:13:34');

DROP TABLE IF EXISTS `backups`;
CREATE TABLE `backups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backups_created_by_foreign` (`created_by`),
  KEY `backups_file_name_index` (`file_name`),
  CONSTRAINT `backups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cache` (`key`,`value`,`expiration`) VALUES
('warehouse-store-management-system-cache-admin@wms.local|127.0.0.1','i:1;','1769220835'),
('warehouse-store-management-system-cache-admin@wms.local|127.0.0.1:timer','i:1769220835;','1769220835'),
('warehouse-store-management-system-cache-admin|127.0.0.1','i:1;','1769233929'),
('warehouse-store-management-system-cache-admin|127.0.0.1:timer','i:1769233929;','1769233929');

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `group_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_group_code_unique` (`group_code`),
  KEY `groups_group_code_index` (`group_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `groups` (`id`,`group_code`,`group_name`,`created_at`,`updated_at`) VALUES
('1','51','Steel Material','2026-01-24 06:52:12','2026-01-24 06:52:12'),
('2','52','Electrical','2026-01-24 06:52:12','2026-01-24 06:52:12'),
('3','53','Hardware','2026-01-24 06:52:12','2026-01-24 06:52:12');

DROP TABLE IF EXISTS `issue_lines`;
CREATE TABLE `issue_lines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `issue_id` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `specification` text COLLATE utf8mb4_unicode_ci,
  `issue_price` int unsigned NOT NULL DEFAULT '0',
  `quantity` int unsigned NOT NULL,
  `line_total` bigint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issue_lines_item_id_index` (`item_id`),
  KEY `issue_lines_issue_id_item_id_index` (`issue_id`,`item_id`),
  CONSTRAINT `issue_lines_issue_id_foreign` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_lines_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `issue_lines` (`id`,`issue_id`,`item_id`,`specification`,`issue_price`,`quantity`,`line_total`,`created_at`,`updated_at`) VALUES
('1','1','2',NULL,'100','5','500','2026-01-24 07:58:36','2026-01-24 07:58:36'),
('2','2','1',NULL,'120','5','600','2026-01-24 10:46:57','2026-01-24 10:46:57');

DROP TABLE IF EXISTS `issue_return_lines`;
CREATE TABLE `issue_return_lines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `issue_return_transaction_id` bigint unsigned NOT NULL,
  `issue_line_id` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `specification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issue_price` int unsigned NOT NULL DEFAULT '0',
  `quantity` int unsigned NOT NULL,
  `line_total` bigint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issue_return_lines_issue_return_transaction_id_foreign` (`issue_return_transaction_id`),
  KEY `issue_return_lines_issue_line_id_foreign` (`issue_line_id`),
  KEY `issue_return_lines_item_id_foreign` (`item_id`),
  CONSTRAINT `issue_return_lines_issue_line_id_foreign` FOREIGN KEY (`issue_line_id`) REFERENCES `issue_lines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_return_lines_issue_return_transaction_id_foreign` FOREIGN KEY (`issue_return_transaction_id`) REFERENCES `issue_return_transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `issue_return_lines_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `issue_return_lines` (`id`,`issue_return_transaction_id`,`issue_line_id`,`item_id`,`specification`,`issue_price`,`quantity`,`line_total`,`created_at`,`updated_at`) VALUES
('1','1','2','1',NULL,'120','1','120','2026-01-24 10:55:53','2026-01-24 10:55:53');

DROP TABLE IF EXISTS `issue_return_transactions`;
CREATE TABLE `issue_return_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `return_date` date NOT NULL,
  `issue_id` bigint unsigned NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issue_return_transactions_issue_id_foreign` (`issue_id`),
  KEY `issue_return_transactions_created_by_foreign` (`created_by`),
  CONSTRAINT `issue_return_transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `issue_return_transactions_issue_id_foreign` FOREIGN KEY (`issue_id`) REFERENCES `issues` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `issue_return_transactions` (`id`,`return_date`,`issue_id`,`notes`,`created_by`,`created_at`,`updated_at`) VALUES
('1','2026-01-24','2','not used','1','2026-01-24 10:55:53','2026-01-24 10:55:53');

DROP TABLE IF EXISTS `issues`;
CREATE TABLE `issues` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `issue_date` date NOT NULL,
  `issued_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `issues_created_by_foreign` (`created_by`),
  KEY `issues_issue_date_index` (`issue_date`),
  CONSTRAINT `issues_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `issues` (`id`,`issue_date`,`issued_to`,`reference_no`,`created_by`,`notes`,`created_at`,`updated_at`) VALUES
('1','2026-01-24','Nauman','2001','1','not used','2026-01-24 07:58:36','2026-01-24 07:58:36'),
('2','2026-01-24','Production','P0-1001','1','Demo Issue','2026-01-24 10:46:57','2026-01-24 10:46:57');

DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `group_id` bigint unsigned NOT NULL,
  `item_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_spec` text COLLATE utf8mb4_unicode_ci,
  `low_stock_threshold` decimal(12,3) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `items_group_id_item_code_unique` (`group_id`,`item_code`),
  KEY `items_item_code_index` (`item_code`),
  CONSTRAINT `items_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `items` (`id`,`group_id`,`item_code`,`name`,`default_spec`,`low_stock_threshold`,`created_at`,`updated_at`) VALUES
('1','1','ST-001','Steel Rod',NULL,NULL,'2026-01-24 06:52:12','2026-01-24 06:52:12'),
('2','1','ST-002','Steel Mug',NULL,NULL,'2026-01-24 06:52:12','2026-01-24 06:52:12'),
('3','1','ST-003','Steel Sheet',NULL,NULL,'2026-01-24 06:52:12','2026-01-24 06:52:12'),
('4','2','EL-001','Copper Wire',NULL,NULL,'2026-01-24 06:52:12','2026-01-24 06:52:12'),
('5','2','EL-002','Switch',NULL,NULL,'2026-01-24 06:52:12','2026-01-24 06:52:12'),
('6','3','HW-001','Nut Bolt Set',NULL,NULL,'2026-01-24 06:52:12','2026-01-24 06:52:12');

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`,`migration`,`batch`) VALUES
('1','0001_01_01_000000_create_users_table','1'),
('2','0001_01_01_000001_create_cache_table','1'),
('3','0001_01_01_000002_create_jobs_table','1'),
('4','2026_01_02_211732_add_role_and_is_active_to_users_table','1'),
('5','2026_01_02_211733_create_groups_table','1'),
('6','2026_01_02_211733_create_items_table','1'),
('7','2026_01_02_211733_create_purchases_table','1'),
('8','2026_01_02_211734_create_issues_table','1'),
('9','2026_01_02_211735_create_backups_table','1'),
('10','2026_01_02_211735_create_issue_lines_table','1'),
('11','2026_01_02_211735_create_system_logs_table','1'),
('12','2026_01_02_211736_create_purchase_lines_table','1'),
('13','2026_01_02_211737_create_stock_ledger_table','1'),
('14','2026_01_05_101347_create_return_transactions_table','1'),
('15','2026_01_05_101357_create_return_lines_table','1'),
('16','2026_01_07_132612_create_backup_settings_table','1'),
('17','2026_01_07_182241_add_stock_threshold_to_items_table','1'),
('18','2026_01_07_183019_create_app_settings_table','1'),
('19','2026_01_18_080000_create_issue_return_transactions_table','1'),
('20','2026_01_18_080001_create_issue_return_lines_table','1'),
('21','2026_01_18_080002_create_purchase_return_transactions_table','1'),
('22','2026_01_18_080003_create_purchase_return_lines_table','1'),
('23','2026_01_18_211541_add_notes_to_stock_ledger_table','1'),
('24','2026_01_18_212530_change_txn_type_to_varchar_in_stock_ledger','1'),
('25','2026_01_19_000001_add_last_run_to_backup_settings_table','1');

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `purchase_lines`;
CREATE TABLE `purchase_lines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `specification` text COLLATE utf8mb4_unicode_ci,
  `purchase_price` int unsigned NOT NULL,
  `quantity` int unsigned NOT NULL,
  `line_total` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_lines_item_id_index` (`item_id`),
  KEY `purchase_lines_purchase_id_item_id_index` (`purchase_id`,`item_id`),
  CONSTRAINT `purchase_lines_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  CONSTRAINT `purchase_lines_purchase_id_foreign` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_lines` (`id`,`purchase_id`,`item_id`,`specification`,`purchase_price`,`quantity`,`line_total`,`created_at`,`updated_at`) VALUES
('1','1','2','10mm','100','10','1000','2026-01-24 07:38:41','2026-01-24 07:38:41'),
('2','2','1','10mm','120','20','2400','2026-01-24 10:12:46','2026-01-24 10:12:46'),
('3','2','6','1dm','100','100','10000','2026-01-24 10:12:46','2026-01-24 10:12:46'),
('4','3','5',NULL,'150','10','1500','2026-01-24 10:53:46','2026-01-24 10:53:46');

DROP TABLE IF EXISTS `purchase_return_lines`;
CREATE TABLE `purchase_return_lines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_return_transaction_id` bigint unsigned NOT NULL,
  `purchase_line_id` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `specification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_price` int unsigned NOT NULL DEFAULT '0',
  `quantity` int unsigned NOT NULL,
  `line_total` bigint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_return_lines_purchase_return_transaction_id_foreign` (`purchase_return_transaction_id`),
  KEY `purchase_return_lines_purchase_line_id_foreign` (`purchase_line_id`),
  KEY `purchase_return_lines_item_id_foreign` (`item_id`),
  CONSTRAINT `purchase_return_lines_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  CONSTRAINT `purchase_return_lines_purchase_line_id_foreign` FOREIGN KEY (`purchase_line_id`) REFERENCES `purchase_lines` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_return_lines_purchase_return_transaction_id_foreign` FOREIGN KEY (`purchase_return_transaction_id`) REFERENCES `purchase_return_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_return_lines` (`id`,`purchase_return_transaction_id`,`purchase_line_id`,`item_id`,`specification`,`purchase_price`,`quantity`,`line_total`,`created_at`,`updated_at`) VALUES
('1','1','2','1','10mm','120','10','1200','2026-01-24 10:46:15','2026-01-24 10:46:15');

DROP TABLE IF EXISTS `purchase_return_transactions`;
CREATE TABLE `purchase_return_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `return_date` date NOT NULL,
  `purchase_id` bigint unsigned NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_return_transactions_purchase_id_foreign` (`purchase_id`),
  KEY `purchase_return_transactions_created_by_foreign` (`created_by`),
  CONSTRAINT `purchase_return_transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `purchase_return_transactions_purchase_id_foreign` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchase_return_transactions` (`id`,`return_date`,`purchase_id`,`notes`,`created_by`,`created_at`,`updated_at`) VALUES
('1','2026-01-24','2',NULL,'1','2026-01-24 10:46:15','2026-01-24 10:46:15');

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `purchase_date` date NOT NULL,
  `supplier_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchases_created_by_foreign` (`created_by`),
  KEY `purchases_purchase_date_index` (`purchase_date`),
  CONSTRAINT `purchases_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `purchases` (`id`,`purchase_date`,`supplier_name`,`reference_no`,`created_by`,`notes`,`created_at`,`updated_at`) VALUES
('1','2026-01-24','Fasi','1011','1','Nothing','2026-01-24 07:38:41','2026-01-24 07:38:41'),
('2','2026-01-24','Local Supplier','IS-2001','1','Okay','2026-01-24 10:12:46','2026-01-24 10:12:46'),
('3','2026-01-24',NULL,NULL,'1',NULL,'2026-01-24 10:53:46','2026-01-24 10:53:46');

DROP TABLE IF EXISTS `return_lines`;
CREATE TABLE `return_lines` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `return_transaction_id` bigint unsigned NOT NULL,
  `item_id` bigint unsigned NOT NULL,
  `specification` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_price` int unsigned NOT NULL DEFAULT '0',
  `quantity` int unsigned NOT NULL,
  `line_total` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `return_lines_return_transaction_id_foreign` (`return_transaction_id`),
  KEY `return_lines_item_id_foreign` (`item_id`),
  CONSTRAINT `return_lines_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  CONSTRAINT `return_lines_return_transaction_id_foreign` FOREIGN KEY (`return_transaction_id`) REFERENCES `return_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `return_transactions`;
CREATE TABLE `return_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `return_date` date NOT NULL,
  `type` enum('IN','OUT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `reference_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `party` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `return_transactions_created_by_foreign` (`created_by`),
  CONSTRAINT `return_transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sessions` (`id`,`user_id`,`ip_address`,`user_agent`,`payload`,`last_activity`) VALUES
('PP2keecsA1EnlTgdD9FUZq7isFF1ooyZ0EHyriU1','1','192.168.1.48','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiRjU0c0xPZEZiMHlKUHFaYXRzZEhhaVpaTEhVZkI5S1RmT0dPUW03aSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzY6Imh0dHA6Ly8xOTIuMTY4LjEuNTg6ODAwMC9wdXJjaGFzZXMvMSI7czo1OiJyb3V0ZSI7czoxNDoicHVyY2hhc2VzLnNob3ciO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM6InVybCI7YTowOnt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTt9','1769229130'),
('qkIpq0mAlcI1NcO5N6YCjVjixm2cDQ81dxzWZC1v','1','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWHEwd3ZmVUV5SjdiMVZXNFBBeFA3dFVpQjFRT2FPY2JudlRSNHBpZSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjI6Imh0dHA6Ly93bXMudGVzdC9iYWNrdXAiO3M6NToicm91dGUiO3M6MTI6ImJhY2t1cC5pbmRleCI7fXM6MzoidXJsIjthOjA6e31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=','1769234307');

DROP TABLE IF EXISTS `stock_ledger`;
CREATE TABLE `stock_ledger` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `txn_date` date NOT NULL,
  `txn_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_table` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_id` bigint unsigned NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `ref_line_id` bigint unsigned DEFAULT NULL,
  `item_id` bigint unsigned NOT NULL,
  `qty_in` int unsigned NOT NULL DEFAULT '0',
  `qty_out` int unsigned NOT NULL DEFAULT '0',
  `unit_price` int unsigned NOT NULL DEFAULT '0',
  `specification_snapshot` text COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_ledger_created_by_foreign` (`created_by`),
  KEY `stock_ledger_item_id_txn_date_index` (`item_id`,`txn_date`),
  KEY `stock_ledger_txn_type_txn_date_index` (`txn_type`,`txn_date`),
  KEY `stock_ledger_ref_table_ref_id_index` (`ref_table`,`ref_id`),
  KEY `stock_ledger_txn_date_index` (`txn_date`),
  CONSTRAINT `stock_ledger_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `stock_ledger_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `stock_ledger` (`id`,`txn_date`,`txn_type`,`ref_table`,`ref_id`,`notes`,`ref_line_id`,`item_id`,`qty_in`,`qty_out`,`unit_price`,`specification_snapshot`,`created_by`,`created_at`,`updated_at`) VALUES
('1','2026-01-24','PURCHASE','purchases','1',NULL,'1','2','10','0','100','10mm','1','2026-01-24 07:38:41','2026-01-24 07:38:41'),
('2','2026-01-24','ISSUE','issues','1',NULL,'1','2','0','5','100',NULL,'1','2026-01-24 07:58:36','2026-01-24 07:58:36'),
('3','2026-01-24','PURCHASE','purchases','2',NULL,'2','1','20','0','120','10mm','1','2026-01-24 10:12:46','2026-01-24 10:12:46'),
('4','2026-01-24','PURCHASE','purchases','2',NULL,'3','6','100','0','100','1dm','1','2026-01-24 10:12:46','2026-01-24 10:12:46'),
('5','2026-01-24','PURCHASE_RETURN_OUT','purchase_return_transactions','1',NULL,'1','1','0','10','120','10mm','1','2026-01-24 10:46:15','2026-01-24 10:46:15'),
('6','2026-01-24','ISSUE','issues','2',NULL,'2','1','0','5','120',NULL,'1','2026-01-24 10:46:57','2026-01-24 10:46:57'),
('7','2026-01-24','PURCHASE','purchases','3',NULL,'4','5','10','0','150',NULL,'1','2026-01-24 10:53:46','2026-01-24 10:53:46'),
('8','2026-01-24','ISSUE_RETURN_IN','issue_return_transactions','1',NULL,'1','1','1','0','120',NULL,'1','2026-01-24 10:55:53','2026-01-24 10:55:53');

DROP TABLE IF EXISTS `system_logs`;
CREATE TABLE `system_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `context_json` json DEFAULT NULL,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `system_logs_created_by_foreign` (`created_by`),
  KEY `system_logs_level_module_index` (`level`,`module`),
  CONSTRAINT `system_logs_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','store_helper') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'store_helper',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`,`name`,`email`,`username`,`email_verified_at`,`password`,`role`,`is_active`,`remember_token`,`created_at`,`updated_at`) VALUES
('1','Admin','farhan987ellahi@gmail.com','admin',NULL,'$2y$12$f0PWipkx3e18IagF5PRDj.PJof//IPh..YONBUyCCC3ulcgd3zY8O','admin','1',NULL,'2026-01-24 06:52:12','2026-01-24 09:32:02'),
('2','Store Helper','helper@local.test','helper',NULL,'$2y$12$XTh45Y406pRXikJmj5/DcOXFvSft8vYeqhQmYBO5/b8rsy.VSlArK','store_helper','1',NULL,'2026-01-24 06:52:12','2026-01-24 06:52:12');

