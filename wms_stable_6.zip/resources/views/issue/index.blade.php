@extends('layouts.app')

@section('content')
<div class="max-w-6xl mx-auto">
    <div class="flex items-start justify-between gap-4 mb-6">
        <div>
            <h1 class="text-2xl font-semibold">Issues (Outward)</h1>
            <p class="mt-1 text-sm text-gray-600">Issue items from store with stock validation.</p>
        </div>

        <a href="{{ route('issues.create') }}"
           class="inline-flex items-center justify-center rounded-lg bg-gray-900 px-4 py-2 text-sm font-medium text-white hover:bg-gray-800">
            New Issue
        </a>
    </div>

    <form method="GET" action="{{ route('issues.index') }}" class="mb-4 rounded-xl border border-gray-200 bg-white p-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
            <div>
                <label class="block text-xs text-gray-600">From</label>
                <input type="date" name="from" value="{{ request('from') }}" class="mt-1 w-full rounded-lg border-gray-200">
            </div>
            <div>
                <label class="block text-xs text-gray-600">To</label>
                <input type="date" name="to" value="{{ request('to') }}" class="mt-1 w-full rounded-lg border-gray-200">
            </div>
            <div>
                <label class="block text-xs text-gray-600">Issued To</label>
                <input type="text" name="issued_to" value="{{ request('issued_to') }}" class="mt-1 w-full rounded-lg border-gray-200" placeholder="Name">
            </div>
            <div>
                <label class="block text-xs text-gray-600">Reference</label>
                <input type="text" name="reference" value="{{ request('reference') }}" class="mt-1 w-full rounded-lg border-gray-200" placeholder="Ref">
            </div>
            <div class="flex gap-2">
                <button class="mt-5 rounded-lg bg-gray-900 px-4 py-2 text-sm font-medium text-white hover:bg-gray-800">Filter</button>
                <a href="{{ route('issues.index') }}" class="mt-5 rounded-lg border border-gray-200 px-4 py-2 text-sm hover:bg-gray-50">Reset</a>
            </div>
        </div>
    </form>

    <div class="flex flex-wrap gap-2 mb-4">
    <a href="{{ route('print.issues', request()->query()) }}" target="_blank"
       class="rounded-lg border border-gray-200 px-4 py-2 text-sm hover:bg-gray-50">Print</a>

    <a href="{{ route('export.issues.csv', request()->query()) }}"
       class="rounded-lg border border-gray-200 px-4 py-2 text-sm hover:bg-gray-50">Export CSV</a>

    <a href="{{ route('export.issues.pdf', request()->query()) }}"
       class="rounded-lg bg-gray-900 px-4 py-2 text-sm text-white hover:bg-gray-800">Export PDF</a>
</div>


    <div class="rounded-xl border border-gray-200 bg-white overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full text-sm">
                <thead class="bg-gray-50 text-gray-600">
                    <tr>
                        <th class="px-4 py-3 text-left">#</th>
                        <th class="px-4 py-3 text-left font-semibold">Date</th>
                        <th class="px-4 py-3 text-left font-semibold">Issued To</th>
                        <th class="px-4 py-3 text-left font-semibold">Ref</th>
                        <th class="px-4 py-3 text-left font-semibold">Created By</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    @forelse($issues as $it)
                        <tr class="hover:bg-gray-50">
                            <td class="px-4 py-3 text-left"><a href="{{ route('issues.show', $it) }}" class="text-indigo-600 hover:underline">#{{ $it->id }}</a></td>
                            <td class="px-4 py-3 whitespace-nowrap">
                                    {{ $it->issue_date->format('Y-m-d') }}
                            </td>
                            <td class="px-4 py-3">{{ $it->issued_to ?? '-' }}</td>
                            <td class="px-4 py-3">{{ $it->reference_no ?? '-' }}</td>
                            <td class="px-4 py-3">{{ $it->creator?->name ?? '-' }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td class="px-4 py-6 text-center text-gray-600" colspan="4">
                                No issues yet.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="mt-4">
        {{ $issues->links() }}
    </div>
</div>
@endsection
