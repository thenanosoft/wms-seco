@extends('layouts.app')

@section('content')
<div class="max-w-5xl mx-auto space-y-6">
    <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
            <h1 class="text-2xl font-semibold">Purchase Details</h1>
            <p class="text-sm text-gray-600">Purchase #{{ $purchase->id }} · {{ optional($purchase->purchase_date)->format('Y-m-d') }}</p>
        </div>
        <div class="flex flex-wrap gap-2">
            <a href="{{ route('purchases.edit', $purchase) }}" class="rounded-lg bg-gray-900 px-4 py-2 text-sm font-medium text-white hover:bg-gray-800">Edit</a>
            <form method="POST" action="{{ route('purchases.destroy', $purchase) }}" onsubmit="return confirm('Delete this purchase? This is only allowed when nothing is issued from it.');">
                @csrf
                @method('DELETE')
                <button type="submit" class="rounded-lg border border-red-200 px-4 py-2 text-sm text-red-700 hover:bg-red-50">Delete</button>
            </form>
            <a href="{{ route('purchases.index') }}" class="rounded-lg border border-gray-200 px-4 py-2 text-sm hover:bg-gray-50">Back</a>
        </div>
    </div>

    <div class="flex flex-wrap gap-2 mb-4">
        <a href="{{ route('print.purchases', request()->query()) }}" target="_blank"
        class="rounded-lg border border-gray-200 px-4 py-2 text-sm hover:bg-gray-50">Print</a>

        <a href="{{ route('export.purchases.csv', request()->query()) }}"
        class="rounded-lg border border-gray-200 px-4 py-2 text-sm hover:bg-gray-50">Export CSV</a>

        <a href="{{ route('export.purchases.pdf', request()->query()) }}"
        class="rounded-lg bg-gray-900 px-4 py-2 text-sm text-white hover:bg-gray-800">Export PDF</a>
    </div>

    <div class="rounded-xl border border-gray-200 bg-white p-4 sm:p-6">
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
            <div><span class="text-gray-500">Supplier</span><div class="font-medium">{{ $purchase->supplier_name ?: '-' }}</div></div>
            <div><span class="text-gray-500">Reference</span><div class="font-medium">{{ $purchase->reference_no ?: '-' }}</div></div>
            <div><span class="text-gray-500">Created By</span><div class="font-medium">{{ optional($purchase->creator)->name ?: '-' }}</div></div>
        </div>
    </div>

    <div class="rounded-xl border border-gray-200 bg-white overflow-hidden">
        <div class="px-4 sm:px-6 py-4 border-b border-gray-200">
            <h2 class="text-lg font-semibold">Items</h2>
        </div>
        <table class="w-full text-sm">
            <thead class="bg-gray-50 text-gray-600">
                <tr>
                    <th class="px-4 py-2 text-left">Item</th>
                    <th class="px-4 py-2 text-right">Qty</th>
                    <th class="px-4 py-2 text-right">Unit Price</th>
                    <th class="px-4 py-2 text-right">Specification</th>
                    <th class="px-4 py-2 text-right">Line Total</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                @foreach($purchase->lines as $line)
                    <tr>
                        <td class="px-4 py-2">
                            <a href="{{ route('items.stock.show', $line->item_id) }}" class="text-indigo-600 hover:underline">
                                {{ optional($line->item)->item_code }} - {{ optional($line->item)->name }}
                            </a>
                        </td>
                        <td class="px-4 py-2 text-right">{{ (int) $line->quantity }}</td>
                        <td class="px-4 py-2 text-right">
                            @if($line->purchase_price === null)
                                <span class="inline-flex items-center rounded-full bg-amber-100 px-2 py-1 text-xs font-semibold text-amber-800">PRICE PENDING</span>
                            @else
                                {{ number_format((float) $line->purchase_price, 0) }}
                            @endif
                        </td>
                        <td class="px-4 py-2 text-right">{{ $line->specification ?: '' }}</td>
                        <td class="px-4 py-2 text-right">{{ number_format((float) ($line->line_total ?? 0), 0) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection
