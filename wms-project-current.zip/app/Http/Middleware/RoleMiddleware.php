<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RoleMiddleware
{
    public function handle(Request $request, Closure $next, ...$roles): Response
    {
        $user = $request->user();

        if (!$user) {
            abort(401);
        }

        if (!$user->is_active) {
            abort(403, 'Your account is disabled.');
        }

        if (!in_array($user->role, $roles, true)) {
            abort(403, 'Access denied.');
        }

        return $next($request);
    }
}
