<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('system_logs', function (Blueprint $table) {
            $table->id();
            $table->string('level');          // info, warning, error
            $table->string('module');         // purchase, issue, backup, auth
            $table->text('message');
            $table->json('context_json')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users');
            $table->timestamps();

            $table->index(['level', 'module']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('system_logs');
    }
};
