<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('groups', function (Blueprint $table) {
            $table->id();
            $table->string('group_code')->unique();
            $table->string('group_name')->nullable();
            $table->timestamps();

            $table->index('group_code');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('groups');
    }
};
